<section>
    <p class="text-center text-3xl m-14">Страница не найдена</p>
    <a href="/" class="btn variant-filled-primary my-14 mx-auto block w-56">На главную страницу</a>
</section>