<h1 class="text-6xl">
    <a href="/">
        Ro<span class="text-primary-500">coco</span>
    </a>
</h1>