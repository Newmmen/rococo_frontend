<script>
import {ProgressRadial} from "@skeletonlabs/skeleton";
</script>

<ProgressRadial
        class="mx-auto my-40"
        stroke={80}
        meter="stroke-primary-500"
        track="stroke-primary-500/30"
        width="w-12"/>