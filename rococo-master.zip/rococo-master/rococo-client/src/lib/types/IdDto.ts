export interface IdDto {
    id: string,
}