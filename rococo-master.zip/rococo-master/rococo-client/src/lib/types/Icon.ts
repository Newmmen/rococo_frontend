import search from "$lib/assets/icons/search.svg";
import menu from "$lib/assets/icons/menu.svg";

export {search as SearchIcon};
export {menu as MenuIcon};
