export type CountryType = {
    id: string;
    name: string;
}