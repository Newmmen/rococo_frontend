<script>
    import NotFound from "$lib/components/NotFound.svelte";
</script>

<NotFound/>
