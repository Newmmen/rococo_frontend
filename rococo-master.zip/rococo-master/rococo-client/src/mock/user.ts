import type { UserType } from "$lib/types/User";

export const user: UserType = {
    id: 1,
    name: "Роксана",
    surname: "Каменева",
    username: "babayanna",
}